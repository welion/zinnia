"""Models for Zinnia"""
from django_comments.moderation import moderator

from zinnia.models.entry import Entry
from zinnia.models.category import Category

from zinnia.signals import connect_entry_signals
from zinnia.signals import connect_discussion_signals

from zinnia.moderator import EntryCommentModerator

# Here we import the Zinnia's Model classes
# to register the Models at the loading, not
# when the Zinnia's URLs are parsed. Issue #161.
# Issue #161, seems not valid since Django 1.7.
__all__ = [Entry.__name__,
           Category.__name__]

# Register the comment moderator on Entry
moderator.register(Entry, EntryCommentModerator)

# Connect the signals
connect_entry_signals()
connect_discussion_signals()
